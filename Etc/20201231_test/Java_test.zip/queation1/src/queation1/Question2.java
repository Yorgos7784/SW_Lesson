package queation1;

public class Question2 {

	public static void main(String[] args) {

		short num1 = 3;
		short num2 = 5;
		System.out.printf("%d + %d = %d\n", num1, num2, num1+num2);

	}

}
