package queation1;

public class Question1 {

	public static void main(String[] args) {

		short num1 = 22;
		short num2 = 11;
		int result = num1 + num2;
		System.out.println(result);

	}

}
